class Brewery {
    constructor(object) {
        Object.assign(this,object);
    }
}

module.exports = Brewery;