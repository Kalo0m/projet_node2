class Geocode {
    constructor(object) {
        Object.assign(this,object);
    }
}

module.exports = Geocode;